#ifndef BINARYSEARCH_H
#define BINARYSEARCH_H

using namespace std;

struct Node {
	string word;
	int times;
	Node* left;
	Node* right;

    Node(string data) : word(data), left(nullptr), right(nullptr) {}
};

struct BinarySearch {
    BinarySearch();
    ~BinarySearch();

	string letter;
	int times;
	BinarySearch* left;
	BinarySearch* right;

    void insert(string data, Node* currNode);
    void remove(Node* currNode);
    void display() const;

    BinarySearch* head;
};

#endif