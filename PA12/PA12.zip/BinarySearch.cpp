#include <iostream>
#include "BinarySearch.h"

using namespace std;

BinarySearch::BinarySearch() : head(nullptr) {}
/*
void BinarySearch::insert (string data, Node* currNode) {
	if (currNode == nullptr) {
		currNode = new Node(data);
	}
	else if (data<currNode->word) {
		currNode->left = insert(data, currNode->left);
	}
	else if (data>currNode->word) {
		currNode->right = insert(data, currNode->right);
	}
	else if (data == currNode->word) {
		currNode->times++;
    }
};

void BinarySearch::remove (Node* currNode) {
	if (currNode == nullptr) {
		delete currNode;
	}
	else if (currNode->left != nullptr) {
		remove(currNode->left);
	}
	else if (currNode->right != nullptr) {
		remove(currNode->right);
	}
};

*/

int main() {
    return 0;


}